using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using LibreHardwareMonitor.Hardware;

namespace Pixo.Data
{
    public class HwComponent
    {
        public string Kind;      // "CPU", "GPU", "Placa-mãe", "SSD"
        public string Name;
        public double? Temp;
        public double? Load;
        public double? VramUsedGb;
        public double? VramTotalGb;
    }

    public class HwSnapshot
    {
        public HwComponent Cpu, Gpu, Board, Ssd;
        public double? CpuLoad;
        public double? RamLoad, RamUsedGb, RamTotalGb;
        public string Error;
        public static readonly HwSnapshot Empty = new HwSnapshot { Error = "Lendo sensores…" };
    }

    /// <summary>
    /// Lê temperaturas e uso pelo LibreHardwareMonitorLib (dentro do próprio app).
    /// Precisa de administrador. Atualiza a cada 2 s em segundo plano.
    /// </summary>
    public static class HardwareService
    {
        private static Computer _computer;
        private static Timer _timer;
        private static int _busy;

        public static volatile HwSnapshot Current = HwSnapshot.Empty;

        private static readonly string[] CpuPreferred = { "CPU Package", "Core (Tctl/Tdie)", "Tctl/Tdie", "Core Average", "Core Max", "CPU Total" };
        private static readonly string[] GpuPreferred = { "GPU Core", "GPU Hot Spot" };
        private static readonly string[] SsdPreferred = { "Composite Temperature", "Temperature", "Temperature 1" };
        private static readonly string[] BoardPreferred = { "System", "Motherboard", "Mainboard", "SYSTIN", "MB" };

        public static void Start()
        {
            _timer = new Timer(_ => Update(), null, 0, 2000);
        }

        public static void Stop()
        {
            _timer?.Dispose();
            try { _computer?.Close(); } catch { }
        }

        private static void Update()
        {
            if (Interlocked.Exchange(ref _busy, 1) == 1) return;
            try
            {
                if (_computer == null)
                {
                    _computer = new Computer
                    {
                        IsCpuEnabled = true,
                        IsGpuEnabled = true,
                        IsMotherboardEnabled = true,
                        IsStorageEnabled = true,
                        IsMemoryEnabled = true
                    };
                    _computer.Open();
                }

                var snap = new HwSnapshot();
                HwComponent intelGpu = null;

                foreach (var hw in _computer.Hardware)
                {
                    hw.Update();
                    foreach (var sub in hw.SubHardware) sub.Update();
                    var sensors = hw.Sensors.Concat(hw.SubHardware.SelectMany(s => s.Sensors)).ToList();

                    switch (hw.HardwareType)
                    {
                        case HardwareType.Cpu:
                            if (snap.Cpu != null) break;
                            snap.Cpu = new HwComponent
                            {
                                Kind = "CPU", Name = hw.Name,
                                Temp = Pick(sensors, SensorType.Temperature, CpuPreferred),
                                Load = Value(sensors, SensorType.Load, "CPU Total")
                            };
                            snap.CpuLoad = snap.Cpu.Load;
                            break;

                        case HardwareType.GpuNvidia:
                        case HardwareType.GpuAmd:
                        case HardwareType.GpuIntel:
                            var used = Value(sensors, SensorType.SmallData, "GPU Memory Used");
                            var total = Value(sensors, SensorType.SmallData, "GPU Memory Total");
                            var gpu = new HwComponent
                            {
                                Kind = "GPU", Name = hw.Name,
                                Temp = Pick(sensors, SensorType.Temperature, GpuPreferred),
                                Load = Value(sensors, SensorType.Load, "GPU Core"),
                                VramUsedGb = used / 1024,
                                VramTotalGb = total / 1024
                            };
                            // prefere a placa de vídeo dedicada à integrada
                            if (hw.HardwareType == HardwareType.GpuIntel) intelGpu ??= gpu;
                            else snap.Gpu ??= gpu;
                            break;

                        case HardwareType.Motherboard:
                            if (snap.Board != null) break;
                            snap.Board = new HwComponent
                            {
                                Kind = "Placa-mãe", Name = hw.Name,
                                Temp = PickContains(sensors, SensorType.Temperature, BoardPreferred)
                            };
                            break;

                        case HardwareType.Storage:
                            var t = Pick(sensors, SensorType.Temperature, SsdPreferred);
                            if (t != null && snap.Ssd == null)
                                snap.Ssd = new HwComponent { Kind = "SSD", Name = hw.Name, Temp = t };
                            break;

                        case HardwareType.Memory:
                            if (snap.RamTotalGb != null) break;
                            snap.RamLoad = Value(sensors, SensorType.Load, "Memory");
                            var u = Value(sensors, SensorType.Data, "Memory Used");
                            var a = Value(sensors, SensorType.Data, "Memory Available");
                            if (u != null && a != null) { snap.RamUsedGb = u; snap.RamTotalGb = u + a; }
                            break;
                    }
                }
                snap.Gpu ??= intelGpu;

                bool anyTemp = new[] { snap.Cpu, snap.Gpu, snap.Board, snap.Ssd }.Any(c => c?.Temp != null);
                snap.Error = anyTemp ? null : "Sem sensores";
                Current = snap;
            }
            catch (Exception)
            {
                Current = new HwSnapshot { Error = "Sem sensores" };
            }
            finally
            {
                Interlocked.Exchange(ref _busy, 0);
            }
        }

        private static double? Value(List<ISensor> sensors, SensorType type, string name)
        {
            var s = sensors.FirstOrDefault(x => x.SensorType == type && x.Name == name);
            return s?.Value;
        }

        private static double? Pick(List<ISensor> sensors, SensorType type, string[] preferred)
        {
            foreach (var p in preferred)
            {
                var v = Value(sensors, type, p);
                if (v != null && v > 0) return v;
            }
            var any = sensors.Where(x => x.SensorType == type && x.Value > 0 && x.Value < 150).Select(x => (double?)x.Value);
            return any.Any() ? any.Max() : null;
        }

        private static double? PickContains(List<ISensor> sensors, SensorType type, string[] preferred)
        {
            var temps = sensors.Where(x => x.SensorType == type && x.Value > 5 && x.Value < 120).ToList();
            foreach (var p in preferred)
            {
                var s = temps.FirstOrDefault(x => x.Name.IndexOf(p, StringComparison.OrdinalIgnoreCase) >= 0);
                if (s != null) return s.Value;
            }
            return temps.FirstOrDefault()?.Value;
        }
    }
}
