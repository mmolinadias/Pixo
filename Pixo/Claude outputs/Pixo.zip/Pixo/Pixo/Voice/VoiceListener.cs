using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using NAudio.Wave;
using Pixo.Core;
using Vosk;

namespace Pixo.Voice
{
    /// <summary>
    /// Comandos de voz offline em português (Vosk + microfone pelo NAudio).
    /// O reconhecimento fica restrito às frases cadastradas, o que deixa tudo mais preciso.
    /// </summary>
    public sealed class VoiceListener : IDisposable
    {
        private readonly Config _cfg;
        private readonly Action<string> _onAction;
        private Model _model;
        private string _modelPath;
        private VoskRecognizer _rec;
        private WaveInEvent _mic;
        private Dictionary<string, string> _map = new Dictionary<string, string>();
        private readonly object _lock = new object();

        public string Status { get; private set; } = "Desligado";
        public bool Listening { get; private set; }
        public string LastHeard { get; private set; } = "";
        public event Action Changed;

        public VoiceListener(Config cfg, Action<string> onAction)
        {
            _cfg = cfg;
            _onAction = onAction;
        }

        public static string Normalize(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            var d = s.ToLowerInvariant().Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder();
            foreach (var c in d)
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
            return sb.ToString().Trim();
        }

        /// <summary>
        /// Arquivo-sentinela: criado antes de carregar o modelo e apagado depois.
        /// Se o app travar no meio (erro nativo do Vosk), na próxima abertura a voz
        /// vem desligada em vez de travar de novo.
        /// </summary>
        private static string CrashMarker => Path.Combine(Config.Folder, "voz-carregando.tmp");

        /// <summary>Chamar ao abrir o app: se a última carga do modelo travou, desliga a voz.</summary>
        public bool RecoverFromCrash()
        {
            if (!File.Exists(CrashMarker)) return false;
            try { File.Delete(CrashMarker); } catch { }
            _cfg.VoiceEnabled = false;
            _cfg.Save();
            SetStatus("A voz travou ao carregar o modelo e foi desligada. Escolha outro modelo (recomendado: vosk-model-small-pt).", false);
            return true;
        }

        /// <summary>Modelo grande (grafo fixo): não aceita lista de comandos como vocabulário.</summary>
        private static bool IsStaticGraphModel(string path) =>
            File.Exists(Path.Combine(path, "graph", "HCLG.fst")) && !File.Exists(Path.Combine(path, "graph", "Gr.fst"));

        private static bool IsBigModel(string path) =>
            Directory.Exists(Path.Combine(path, "rnnlm")) || IsStaticGraphModel(path);

        /// <summary>Liga (ou religa, depois de mudar comandos/modelo) conforme a configuração.
        /// Carrega o modelo em segundo plano para a janela não congelar.</summary>
        public void Restart()
        {
            Stop();
            if (!_cfg.VoiceEnabled) { SetStatus("Desligado", false); return; }

            var path = _cfg.VoiceModelPath;
            if (!Directory.Exists(path) || !Directory.Exists(Path.Combine(path, "am")))
            {
                SetStatus("Modelo de voz não encontrado", false);
                return;
            }
            if (path.Any(ch => ch > 127))
            {
                SetStatus("O caminho do modelo tem acentos ou símbolos. Mova a pasta para um caminho simples, ex.: C:\\Pixo\\modelo-voz", false);
                return;
            }

            bool big = IsBigModel(path);
            SetStatus(big ? "Carregando modelo grande… (pode levar 1 minuto)" : "Carregando modelo…", false);
            System.Threading.Tasks.Task.Run(() => Load(path, big));
        }

        private void Load(string path, bool big)
        {
            try
            {
                Vosk.Vosk.SetLogLevel(-1);
                if (_model == null || _modelPath != path)
                {
                    _model?.Dispose();
                    _model = null;
                    Directory.CreateDirectory(Config.Folder);
                    File.WriteAllText(CrashMarker, path);
                    _model = new Model(path);
                    _modelPath = path;
                    try { File.Delete(CrashMarker); } catch { }
                }

                var commands = _cfg.VoiceCommands.Where(c => !string.IsNullOrWhiteSpace(c.Phrase) && !string.IsNullOrWhiteSpace(c.Action)).ToList();
                _map = new Dictionary<string, string>();
                foreach (var c in commands) _map[Normalize(c.Phrase)] = c.Action;

                lock (_lock)
                {
                    if (IsStaticGraphModel(path))
                    {
                        // modelo grande: reconhece a fala livre e o Pixo procura os comandos nela
                        _rec = new VoskRecognizer(_model, 16000f);
                    }
                    else
                    {
                        var grammar = commands.Select(c => c.Phrase.Trim().ToLowerInvariant()).Distinct().ToList();
                        grammar.Add("[unk]");
                        // mantém os acentos como texto (sem \u00e1), que é o que o Vosk espera
                        var json = JsonSerializer.Serialize(grammar, new JsonSerializerOptions
                        {
                            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                        });
                        _rec = new VoskRecognizer(_model, 16000f, json);
                    }
                }

                if (WaveInEvent.DeviceCount == 0)
                {
                    SetStatus("Nenhum microfone encontrado", false);
                    return;
                }
                _mic = new WaveInEvent { WaveFormat = new WaveFormat(16000, 16, 1), BufferMilliseconds = 100, DeviceNumber = 0 };
                _mic.DataAvailable += OnAudio;
                _mic.StartRecording();
                SetStatus("Ouvindo", true);
            }
            catch (Exception ex)
            {
                SetStatus("Erro na voz: " + ex.Message, false);
            }
        }

        private void OnAudio(object sender, WaveInEventArgs e)
        {
            string text = null;
            lock (_lock)
            {
                if (_rec == null) return;
                if (_rec.AcceptWaveform(e.Buffer, e.BytesRecorded))
                {
                    try
                    {
                        using var doc = JsonDocument.Parse(_rec.Result());
                        text = doc.RootElement.TryGetProperty("text", out var t) ? t.GetString() : null;
                    }
                    catch { }
                }
            }
            if (string.IsNullOrWhiteSpace(text) || text == "[unk]") return;

            var norm = Normalize(text);
            // a frase mais longa primeiro ("desligar tela" antes de "tela")
            foreach (var key in _map.Keys.OrderByDescending(k => k.Length))
            {
                if ((" " + norm + " ").Contains(" " + key + " "))
                {
                    LastHeard = text;
                    Changed?.Invoke();
                    _onAction(_map[key]);
                    return;
                }
            }
        }

        private void SetStatus(string s, bool listening)
        {
            Status = s;
            Listening = listening;
            Changed?.Invoke();
        }

        public void Stop()
        {
            try
            {
                if (_mic != null)
                {
                    _mic.DataAvailable -= OnAudio;
                    _mic.StopRecording();
                    _mic.Dispose();
                }
            }
            catch { }
            _mic = null;
            lock (_lock)
            {
                _rec?.Dispose();
                _rec = null;
            }
            Listening = false;
        }

        public void Dispose()
        {
            Stop();
            _model?.Dispose();
            _model = null;
        }
    }
}
